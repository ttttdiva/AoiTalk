(() => {
  const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const easeOut = (t) => 1 - Math.pow(1 - clamp(t), 3);
  const easeInOut = (t) => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

  const body = document.body;
  const root = document.documentElement;
  const header = document.querySelector('[data-header]');
  const progressBar = document.querySelector('.progress span');
  const hero = document.querySelector('[data-hero]');
  const orbitItems = [...document.querySelectorAll('[data-orbit-item]')];
  const featuredOrbitItems = orbitItems.filter((item) => item.dataset.featured === 'true');
  const featuredCount = Math.max(1, featuredOrbitItems.length);
  const floatItems = [...document.querySelectorAll('.floatItem')];
  const zones = [...document.querySelectorAll('[data-zone]')];
  const gallery = document.querySelector('[data-gallery]');
  const galleryTrack = document.querySelector('[data-gallery-track]');
  const menuButton = document.querySelector('[data-menu-button]');
  const drawer = document.querySelector('[data-drawer]');

  let latestY = window.scrollY;
  let ticking = false;
  let viewportW = window.innerWidth;
  let viewportH = window.innerHeight;

  function refreshViewport() {
    viewportW = window.innerWidth || document.documentElement.clientWidth || 1;
    viewportH = window.innerHeight || document.documentElement.clientHeight || 1;
  }

  function heroMetrics() {
    // The photo ring used to mix vw for X and vh for Y. On wide/large monitors this stretched
    // the ring horizontally and made the cards look tiny. Keep laptop-sized layouts almost
    // unchanged, but cap the X unit against viewport height when the viewport is very wide.
    const aspect = viewportW / Math.max(1, viewportH);
    const wideStrength = clamp((aspect - 1.85) / .65);
    const largeStrength = clamp((viewportW - 1800) / 2200) * .18;
    const capStrength = Math.max(wideStrength, largeStrength);
    const rawX = viewportW / 100;
    const cappedX = Math.min(rawX, Math.max(viewportH / 58, viewportW / 135));
    const xUnit = lerp(rawX, cappedX, capStrength);
    const yUnit = viewportH / 100;
    const depthScale = 1 + clamp((viewportW - 1600) / 1600) * .08;
    return { xUnit, yUnit, depthScale };
  }

  const setLoaded = () => body.classList.add('isLoaded');
  window.addEventListener('load', () => setTimeout(setLoaded, 350));
  setTimeout(setLoaded, 1400);

  menuButton?.addEventListener('click', () => drawer?.classList.toggle('isOpen'));
  drawer?.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => drawer.classList.remove('isOpen')));

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) entry.target.classList.add('isVisible');
    });
  }, { threshold: .18 });
  document.querySelectorAll('.revealBlock').forEach((el) => revealObserver.observe(el));

  function rectProgress(el, startOffset = 0, endOffset = 0) {
    const rect = el.getBoundingClientRect();
    const total = rect.height - viewportH + startOffset + endOffset;
    const passed = -rect.top + startOffset;
    return clamp(total <= 0 ? 0 : passed / total);
  }

  function n(el, name, fallback = 0) {
    const v = Number(el.dataset[name]);
    return Number.isFinite(v) ? v : fallback;
  }

  const ORB_POINTS = [
    { a: -2.74, r: 1.18, s: .94, o: .00 },
    { a: -2.06, r: .86, s: 1.14, o: .24 },
    { a: -1.42, r: 1.28, s: .82, o: .48 },
    { a: -.78, r: .96, s: 1.06, o: .72 },
    { a: -.12, r: 1.20, s: .90, o: .96 },
    { a: .48, r: .78, s: 1.26, o: 1.20 },
    { a: 1.02, r: 1.32, s: .84, o: 1.44 },
    { a: 1.68, r: .92, s: 1.12, o: 1.68 },
    { a: 2.28, r: 1.10, s: .96, o: 1.92 },
    { a: 2.86, r: .70, s: 1.34, o: 2.16 }
  ];

  function createMorphOrbs() {
    orbitItems.forEach((item) => {
      if (item.dataset.featured !== 'true') return;
      const frame = item.querySelector('.photoFrame');
      if (!frame) return;

      const existing = [...frame.querySelectorAll('.morphOrb')];
      if (existing.length) {
        item._morphOrbs = existing;
        return;
      }
      item._morphOrbs = ORB_POINTS.map((point, index) => {
        const orb = document.createElement('span');
        orb.className = 'morphOrb';
        orb.setAttribute('aria-hidden', 'true');
        orb.style.setProperty('--orb-size-factor', point.s);
        orb.style.setProperty('--orb-delay-factor', index / ORB_POINTS.length);
        const illust = frame.querySelector('.illustCut');
        if (illust) frame.insertBefore(orb, illust);
        else frame.appendChild(orb);
        return orb;
      });
    });
  }

  createMorphOrbs();

  function updateHero() {
    if (!hero) return;
    const p = rectProgress(hero, 0, 0);
    const metrics = heroMetrics();
    const gather = easeOut(clamp(p / .28));
    const focus = easeInOut(clamp((p - .32) / .14));
    const extract = easeInOut(clamp((p - .42) / .18));
    const lightIn = easeInOut(clamp((p - .58) / .10));
    const lightGather = easeInOut(clamp((p - .63) / .18));
    const illustReveal = easeInOut(clamp((p - .71) / .13));
    const travel = easeInOut(clamp((p - .78) / .14));
    const orbitRun = clamp((p - .86) / .12);
    const orbitEase = easeInOut(orbitRun);
    const outro = clamp((p - .985) / .015);

    root.style.setProperty('--hero-p', p.toFixed(4));
    root.style.setProperty('--gather', gather.toFixed(4));
    root.style.setProperty('--focus', focus.toFixed(4));
    root.style.setProperty('--extract', extract.toFixed(4));
    root.style.setProperty('--central', travel.toFixed(4));
    root.style.setProperty('--hero-bg-scale', (1.02 + p * .055).toFixed(4));
    root.style.setProperty('--hero-bg-rotate', `${(p * 2.2).toFixed(3)}deg`);
    root.style.setProperty('--hero-copy-opacity', clamp(1 - focus * .92).toFixed(4));
    root.style.setProperty('--hero-copy-x', `${(-2 * gather).toFixed(3)}vw`);
    root.style.setProperty('--hero-copy-y', `${(-4 * gather).toFixed(3)}vh`);
    root.style.setProperty('--hero-copy-scale', (1 - gather * .035).toFixed(4));
    root.style.setProperty('--guide-scale', (.75 + gather * .25).toFixed(4));
    root.style.setProperty('--guide-opacity', (gather * (1 - travel * .82)).toFixed(4));
    root.style.setProperty('--core-opacity', (.10 + travel * .74).toFixed(4));
    root.style.setProperty('--core-rotate', '0deg');
    root.style.setProperty('--core-scale', (.78 + travel * .22).toFixed(4));
    root.style.setProperty('--hint-opacity', (1 - clamp((p - .56) / .22) * .78).toFixed(4));

    // Keep the fixed header out of the hero animation until the opening sequence is almost finished.
    // This prevents the upper orbit photos from being covered by the navigation chrome.
    header?.classList.toggle('isHeroHidden', p < .94);

    const tiltMap = [0, 0, 0, 0, 0, 0];

    orbitItems.forEach((item, i) => {
      const sx = n(item, 'startX');
      const sy = n(item, 'startY');
      const rx = n(item, 'ringX');
      const ry = n(item, 'ringY');
      const sr = n(item, 'startR');
      const rr = n(item, 'ringR');
      const cx = n(item, 'clusterX');
      const cy = n(item, 'clusterY');
      const angleBase = n(item, 'angle');
      const delay = n(item, 'delay');
      const layoutScale = clamp(n(item, 'size', 1), .74, 1.18);
      const ringSpreadX = 1.00;
      const ringSpreadY = 1.00;
      const ringOffsetY = 0.0;
      const hasPerson = item.dataset.featured === 'true';
      const memberIndex = Math.max(0, n(item, 'member', 1) - 1);
      const slotIndex = hasPerson ? Math.max(0, featuredOrbitItems.indexOf(item)) : 0;
      const personAnchorX = n(item, 'personX');
      const personAnchorY = n(item, 'personY');
      const highlightX = n(item, 'highlightX', personAnchorX);
      const highlightY = n(item, 'highlightY', personAnchorY);
      const personBaseScale = n(item, 'personScale', 1);
      const objectX = n(item, 'objectX', 50);
      const objectY = n(item, 'objectY', 50);
      const illustAnchorX = n(item, 'illustX', personAnchorX);
      const illustAnchorY = n(item, 'illustY', personAnchorY);
      const illustBaseScale = n(item, 'illustScale', personBaseScale);

      const localGather = easeOut(clamp((p - delay) / .30));
      const baseX = lerp(sx, rx * ringSpreadX, localGather);
      const baseY = lerp(sy, ry * ringSpreadY + ringOffsetY, localGather);
      const baseR = lerp(sr, rr, localGather);

      let x = baseX;
      let y = baseY;
      let z = 0;
      let scale = lerp(.76, 1, localGather) * lerp(1, layoutScale, localGather);
      let rotate = baseR;
      let itemOpacity = 1;
      let photoOpacity = 1;
      let photoBrightness = 1;
      let photoSaturate = 1;
      let photoBlur = 0;
      let veilOpacity = 0;
      let frameOpacity = .55;
      let personOpacity = 0;
      let personRise = 0;
      let personScale = personBaseScale;
      let personGlowOpacity = 0;
      let illustOpacity = 0;
      let illustRise = 0;
      let illustScale = illustBaseScale;
      let illustGlowOpacity = 0;
      let orbOpacity = 0;
      let orbSpread = 34;
      let orbScale = .70;
      let orbGlowOpacity = 0;
      let labelOpacity = 1;

      if (hasPerson) {
        // After morphing, each member joins a fixed, equally spaced slot on the 3D orbit.
        // The pre-morph photo placement remains controlled by the original start/ring data.
        const slotDegrees = -90 + slotIndex * (360 / featuredCount);
        const theta = (slotDegrees + orbitEase * 360 * 2.85) * Math.PI / 180;
        const orbitRadiusX = 17.4;
        const orbitRadiusY = 6.6;
        const orbitDepth = 420 * metrics.depthScale;
        const orbitX = Math.sin(theta) * orbitRadiusX;
        const orbitY = Math.cos(theta) * orbitRadiusY;
        const orbitZ = Math.cos(theta) * orbitDepth;
        const joinArc = Math.sin(travel * Math.PI);
        const tangentX = Math.cos(theta) * 7.6;
        const tangentY = -Math.sin(theta) * 2.8;
        const depth01 = clamp((orbitZ + orbitDepth) / (orbitDepth * 2));
        const finalTilt = tiltMap[memberIndex % tiltMap.length];
        const straighten = clamp(illustReveal * .72 + travel * .72);
        const finalSizeNorm = clamp(252 / Math.max(1, item.offsetWidth || 252), .62, 1.24);
        const finalScale = (.69 + depth01 * .20) * finalSizeNorm;

        x = lerp(baseX, orbitX, travel) + tangentX * joinArc;
        y = lerp(baseY, orbitY, travel) + tangentY * joinArc;
        z = lerp(0, orbitZ, travel);
        rotate = lerp(baseR, finalTilt, straighten);
        scale = lerp(scale, finalScale, travel) * lerp(1, .97, outro);
        itemOpacity = lerp(1, .95, outro);
        frameOpacity = (1 - illustReveal * .82) * (1 - travel * .78) * .55;

        // First remove the original photo/background. The separate person cutout remains fixed in place.
        photoOpacity = clamp(1 - focus * .10 - extract * .86 - lightIn * .10 - travel * .10);
        photoBrightness = clamp(1 - focus * .05 - extract * .22 - lightIn * .10);
        photoSaturate = clamp(1 - focus * .12 - extract * .30 - lightIn * .10);
        photoBlur = (focus * .16 + extract * .34) * (1 - lightIn * .72);
        veilOpacity = clamp(focus * .20 + extract * .50) * (1 - lightIn * .82) * (1 - travel * .70);

        // No rise and no animated scale: the cutout position does not drift from the photo.
        personOpacity = focus * (1 - lightIn * .86) * (1 - illustReveal * .55);
        personRise = 0;
        personScale = personBaseScale;
        personGlowOpacity = clamp((focus * .78 + extract * .22) * (1 - lightIn * .58));

        // Light balls appear after the surrounding photo has already faded.
        orbOpacity = clamp(lightIn * (1 - illustReveal * .82) * (1 - travel * .28));
        orbSpread = lerp(62, 26, lightGather);
        orbScale = lerp(.98, 1.36, lightIn) * lerp(1, .74, illustReveal);
        orbGlowOpacity = clamp((.18 + lightIn * .34) * (1 - illustReveal * .18));

        illustOpacity = illustReveal;
        illustRise = (1 - illustReveal) * 2;
        illustScale = illustBaseScale * lerp(.96, 1.01, illustReveal);
        illustGlowOpacity = illustReveal * .30;
        labelOpacity = clamp(1 - focus * .88 - travel);
      } else {
        const ghostFade = easeInOut(clamp((p - .34) / .24));
        rotate = baseR * (1 - ghostFade * .10);
        scale *= lerp(1, .88, ghostFade);
        itemOpacity = (1 - ghostFade * .96) * (1 - outro * .2);
        photoOpacity = clamp(1 - ghostFade * .74);
        photoSaturate = 1 - ghostFade * .62;
        photoBlur = ghostFade * 2.8;
        veilOpacity = focus * (1 - ghostFade) * .30;
        frameOpacity = (1 - ghostFade) * .55;
        labelOpacity = clamp(1 - ghostFade);
      }

      const xPx = x * metrics.xUnit;
      const yPx = y * metrics.yUnit;
      item.style.transform = `translate(-50%, -50%) translate3d(${xPx.toFixed(1)}px, ${yPx.toFixed(1)}px, ${z.toFixed(1)}px) rotateZ(${rotate.toFixed(2)}deg) scale(${scale.toFixed(4)})`;
      item.style.opacity = itemOpacity.toFixed(3);
      item.style.zIndex = String(hasPerson ? 40 + Math.round((z + 260) / 10) : 12);
      item.style.setProperty('--focus', focus.toFixed(4));
      item.style.setProperty('--extract', extract.toFixed(4));
      item.style.setProperty('--illust', illustReveal.toFixed(4));
      item.style.setProperty('--person-x', `${personAnchorX.toFixed(3)}%`);
      item.style.setProperty('--person-y', `${personAnchorY.toFixed(3)}%`);
      item.style.setProperty('--highlight-x', `${highlightX.toFixed(3)}%`);
      item.style.setProperty('--highlight-y', `${highlightY.toFixed(3)}%`);
      item.style.setProperty('--object-x', `${objectX.toFixed(3)}%`);
      item.style.setProperty('--object-y', `${objectY.toFixed(3)}%`);
      item.style.setProperty('--illust-x', `${illustAnchorX.toFixed(3)}%`);
      item.style.setProperty('--illust-y', `${illustAnchorY.toFixed(3)}%`);
      item.style.setProperty('--frame-opacity', frameOpacity.toFixed(4));
      item.style.setProperty('--frame-bg-opacity', (frameOpacity * .15).toFixed(4));
      item.style.setProperty('--frame-shadow-opacity', (frameOpacity * .52).toFixed(4));
      item.style.setProperty('--photo-opacity', photoOpacity.toFixed(4));
      item.style.setProperty('--photo-brightness', photoBrightness.toFixed(4));
      item.style.setProperty('--photo-saturate', photoSaturate.toFixed(4));
      item.style.setProperty('--photo-blur', `${photoBlur.toFixed(3)}px`);
      item.style.setProperty('--veil-opacity', veilOpacity.toFixed(4));
      item.style.setProperty('--person-opacity', personOpacity.toFixed(4));
      item.style.setProperty('--person-rise', `${personRise.toFixed(3)}px`);
      item.style.setProperty('--person-scale', personScale.toFixed(4));
      item.style.setProperty('--person-glow-opacity', personGlowOpacity.toFixed(4));
      item.style.setProperty('--orb-opacity', orbOpacity.toFixed(4));
      item.style.setProperty('--orb-scale', orbScale.toFixed(4));
      item.style.setProperty('--orb-glow-opacity', orbGlowOpacity.toFixed(4));
      item.style.setProperty('--illust-opacity', illustOpacity.toFixed(4));
      item.style.setProperty('--illust-rise', `${illustRise.toFixed(3)}px`);
      item.style.setProperty('--illust-scale', illustScale.toFixed(4));
      item.style.setProperty('--illust-glow-opacity', illustGlowOpacity.toFixed(4));
      item.style.setProperty('--label-opacity', labelOpacity.toFixed(4));

      const orbs = item._morphOrbs || [];
      orbs.forEach((orb, orbIndex) => {
        const point = ORB_POINTS[orbIndex % ORB_POINTS.length];
        const spiral = clamp(lightIn * .58 + lightGather * .82);
        const spin = spiral * Math.PI * (4.15 + memberIndex * .31) + p * Math.PI * .90;
        const thetaOrb = point.a + spin + point.o + memberIndex * .42;

        // Side-view helix: the path contracts horizontally while the swirl itself turns through Y/Z depth.
        // This avoids the previous top-down whirlpool look, where X/Y formed a flat circle on the screen.
        const axisX = lerp(
          Math.cos(point.a + memberIndex * .18) * point.r * orbSpread * 1.04,
          Math.cos(point.a + memberIndex * .22) * (12 + point.r * 5.5),
          lightGather
        );
        const coilRadius = lerp(point.r * orbSpread * .58, 11 + point.r * 4.8, lightGather);
        const horizontalWobble = Math.sin(thetaOrb * .64 + point.o) * coilRadius * .30;
        const fineWobble = Math.sin(thetaOrb * 1.75 + orbIndex * .71) * lerp(4.6, 1.35, lightGather);
        const xOrb = axisX + horizontalWobble + fineWobble;
        const yOrb = Math.sin(thetaOrb) * coilRadius * .96 + Math.cos(thetaOrb * .52 + memberIndex) * lerp(4.2, 1.15, lightGather);
        const zOrb = Math.cos(thetaOrb) * lerp(82, 34, lightGather);
        const depthScale = lerp(.78, 1.18, (Math.cos(thetaOrb) + 1) / 2);

        orb.style.setProperty('--orb-x', `${xOrb.toFixed(3)}px`);
        orb.style.setProperty('--orb-y', `${yOrb.toFixed(3)}px`);
        orb.style.setProperty('--orb-z', `${zOrb.toFixed(3)}px`);
        orb.style.setProperty('--orb-size-total', (orbScale * point.s * depthScale).toFixed(4));
      });
    });
  }

  function updateZones() {
    zones.forEach((zone) => {
      const p = rectProgress(zone, 0, 0);
      const e = easeInOut(p);
      const bg = zone.querySelector('.zoneBg');
      const title = zone.querySelector('.zoneTitle');
      const small = zone.querySelector('.zoneSmall');
      const panel = zone.querySelector('.zonePanel');
      const illust = zone.querySelector('.zoneIllust');
      const reverse = zone.dataset.theme === 'eat';
      const dir = reverse ? -1 : 1;

      if (bg) {
        bg.style.transform = `scale(${lerp(1.18, 1.02, e)}) translate3d(${lerp(0, dir * 2.8, e)}vw, 0, 0)`;
        bg.style.filter = `blur(${lerp(12, 2, e)}px)`;
      }
      if (title) {
        title.style.transform = `translate3d(${lerp(-34 * dir, 4 * dir, easeOut(p))}vw, ${lerp(8, -4, e)}vh, 0) rotate(${lerp(-3 * dir, 0, e)}deg)`;
        title.style.opacity = String(lerp(.1, .95, clamp(p / .42)) * (1 - clamp((p - .86) / .14) * .72));
      }
      if (small) {
        small.style.transform = `translate3d(0, ${lerp(90, -12, e)}px, 0)`;
        small.style.opacity = String(lerp(0, 1, clamp((p - .05) / .28)));
      }
      if (panel) {
        panel.style.transform = `translate3d(${lerp(30 * dir, 0, easeOut(clamp((p - .18) / .45)))}vw, ${lerp(80, 0, easeOut(clamp((p - .18) / .45)))}px, 0) rotate(${lerp(5 * dir, 0, e)}deg)`;
        panel.style.opacity = String(lerp(0, 1, clamp((p - .16) / .34)));
      }
      if (illust) {
        illust.style.transform = `translate3d(${lerp(-18 * dir, 14 * dir, e)}vw, ${lerp(90, -20, e)}px, 0) rotate(${lerp(-18 * dir, 370 * dir, e)}deg) scale(${lerp(.74, 1.04, e)})`;
        illust.style.opacity = String(lerp(0, 1, clamp((p - .08) / .3)) * (1 - clamp((p - .9) / .1) * .55));
      }
    });
  }

  function updateGallery() {
    if (!gallery || !galleryTrack) return;
    const p = rectProgress(gallery, 0, 0);
    const maxX = Math.max(0, galleryTrack.scrollWidth - window.innerWidth + 40);
    galleryTrack.style.transform = `translate3d(${-maxX * easeInOut(p)}px, 0, 0)`;
  }

  function updateFloat(time = 0) {
    const t = time / 1000;
    floatItems.forEach((el, i) => {
      const amp = Number(el.dataset.float || 1);
      const y = Math.sin(t * .9 + i) * 8 * amp;
      const x = Math.cos(t * .7 + i * 1.7) * 5 * amp;
      el.style.transform = `translate3d(${x}px, ${y}px, 0) rotate(${Math.sin(t + i) * 2.5}deg)`;
    });
    requestAnimationFrame(updateFloat);
  }

  function update() {
    ticking = false;
    latestY = window.scrollY || window.pageYOffset;
    const doc = document.documentElement;
    const max = Math.max(1, doc.scrollHeight - viewportH);
    root.style.setProperty('--scroll-progress', String(clamp(latestY / max)));
    progressBar?.style.setProperty('width', `${clamp(latestY / max) * 100}%`);
    header?.classList.toggle('isCompact', latestY > 70);
    updateHero();
    updateZones();
    updateGallery();
  }

  function requestUpdate() {
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(update);
    }
  }

  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', () => {
    refreshViewport();
    requestUpdate();
  });
  refreshViewport();
  requestAnimationFrame(updateFloat);
  update();
})();
