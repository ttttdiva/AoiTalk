# orbit_scroll_animation_fixed_v13

v13はv12を土台に、写真比率・人物切り抜きサイズ・イラスト合流軌道を修正した版です。

## 修正内容

- v9/v10/v11で混入した不要な写真配置変更を破棄
- 参考画像に近い外周コラージュ配置へ再設計
- 写真は中央に集めず、外側から外周コラージュ位置へ入る動きに変更
- 写真ごとに個別サイズ・個別傾き・個別位置を指定
- 写真カードのサイズをv11より大きく調整
- `photo-11.webp` / `photo-12.webp` / `photo-14.webp` / `photo-15.webp` はヒーローから除外し、ZIP内からも削除
- 人物切り抜きは `person-full-*` を使用し、元写真と同一キャンバスサイズで固定
- 写真カードは `--card-width` / `--card-aspect` を実際に使用し、元写真のアスペクト比で表示
- featured写真の `.photoImg` と `.personCut` は同じ表示矩形・`object-fit: cover`・`object-position: 50% 50%`・`transform:none` に固定
- 人物切り抜きは元写真と同一キャンバスのまま重ね、切り抜きだけ拡大されないように固定
- イラスト化後は中央へ直線集合させず、等間隔スロットの3D円軌道へ曲線合流
- イラスト化前の写真配置用 `data-start-*` / `data-ring-*` は変更なし
- 光の玉は数を削らず、1点へ完全収束しない横向きの広がりを残す軌道へ修正

## 検証

- `node --check script.js` 通過
- HTML内画像参照の存在チェック通過
- 除外対象4枚の参照・ファイル不存在を確認
- featured 6枚の元写真と人物フルキャンバス画像のサイズ一致を確認
- `node --check script.js` 通過（v13）


## v16 fixed notes
- Wide/large viewport hero orbit now uses pixel units derived from viewport height instead of raw vw/vh mixing, so the photo ring does not stretch horizontally on ultrawide or large monitors.
- Orbit guide expands on desktop-wide viewports to match the actual ring.
- Desktop maximum photo card sizes were increased while keeping min/preferred values unchanged, preserving notebook layout.
- Featured photo/person cutout canvas lock is unchanged; photo and cutout remain the same size and position.
- Mobile nth-of-type sizing is limited to ghost photos so featured/person items are not accidentally resized.
